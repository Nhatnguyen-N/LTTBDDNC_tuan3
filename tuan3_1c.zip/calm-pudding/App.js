import * as React from 'react';
import { Text, View, StyleSheet,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.tile}>
      <Text style={styles.item1} >CODE</Text>
      <Text style={styles.item2}>VERIFICATION</Text>
      <Text style={styles.item3}>Enter ontime password sent on
            ++849092605798</Text>
      </View>
      <View style={styles.container1}>
        <View style={styles.item4}></View>
        <View style={styles.item4}></View>
        <View style={styles.item4}></View>
        <View style={styles.item4}></View>
        <View style={styles.item4}></View>
        <View style={styles.item4}></View>
      </View>
      <View style={styles.container3}>
        <TouchableOpacity
          style={{
            backgroundColor:"#E3C000",
            height:50,
            width:300,
            padding:13,
            marginRight:20,
            alignItems:'center',
            
            }}
          onPress={this.onPress}
        >
          <Text style={{
            fontSize: 16,
            fontWeight: 500,}}>VERIFY CODE</Text>
        </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    background: 'linear-gradient(180deg, rgba(199, 244, 247, 0) 0.03%, #D1F4F6 30.21%, #E5F4F5 85.42%, #00CCF9 100%)',
    padding: 8,
  },
  tile: {
    flex:1,
    textAlign:'center',
    marginTop:'50px'
  },
  item1:{
    fontSize:50,
    fontWeight:500,
  },
  item2:{
    paddingTop:30,
    fontSize:20,
    fontWeight:500,
  },
  item3:{
    paddingTop:50,
    padding:10,
    fontWeight:500
  },
  container1:{
    
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
  },
  item4:{
    border:'1px solid',
    width:45,
    height:40,
  },
  container3:{
    flex:1,
    padding:10,
    paddingTop:30,
    
    
  }
});
