import * as React from 'react';
import { Text, View, StyleSheet,Image,Button,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={{flex:1}}>
        <View style={{
          flex:1,
           border:'10px solid black',
           width:120,
           height:100,
           borderRadius:'100%',
           marginLeft:'30%',
           marginTop:10}}/>
      </View>
      <View style={{
        flex:1,
        textAlign:'center',
        marginTop:10,
        
      }}>
        <Text style={{
            fontSize: 30,
            fontWeight: "500",

        }}>GROW <br/>YOUR BUSINESS</Text>
      </View>
      <View style={{
        flex:1,
        textAlign:'center',
        marginTop:10,}}>
        <Text style={{
            fontSize: 15,
            fontWeight: "500",

        }}>We will help you to grow your business using nonline server</Text>
      </View>
      <View style={{flex:1,
       flexDirection:'row',
       justifyContent: 'space-between',
       }}>
       <TouchableOpacity
          style={{
            backgroundColor:"#E3C000",
            height:50,
            width:100,
            padding:13,
            marginLeft:20,
            alignItems:'center',
            }}
          onPress={this.onPress}
        >
          <Text style={{
            fontSize: 15,
            fontWeight: "500",}}>LOG IN</Text>
        </TouchableOpacity>
      <TouchableOpacity
          style={{
            backgroundColor:"#E3C000",
            height:50,
            width:100,
            padding:13,
            marginRight:20,
            alignItems:'center',
            }}
          onPress={this.onPress}
        >
          <Text style={{
            fontSize: 15,
            fontWeight: "500",}}>SIGN UP</Text>
        </TouchableOpacity>
      </View>
      <View style={{flex:1,
      textAlign:'center',
        marginTop:10,}}>
        <Text style={{
            fontSize: 25,
            fontWeight: "500",

        }}>HOW WE WORK?</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    background:'linear-gradient(180deg, rgba(196, 196, 196, 0) 0%, #28F7AC 100%)',
    padding:10,
  },
  
});
