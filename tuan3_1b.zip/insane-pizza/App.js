import * as React from 'react';
import { Text, View, StyleSheet,Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={{flex:1}}>
        <Image
        source={require('@expo/snack-static/react-native-logo.png')}
        />
      </View>
      <View style={{flex:1}}>A</View>
      <View style={{flex:1}}><Text>FORGET PASSWORD</Text></View>
      <View style={{flex:1}}><Text>Provide your account’s email for which you want to reset your password</Text></View>
      <View style={{flex:1}}>D</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    background: 'linear-gradient(180deg, rgba(189, 246, 198, 0) 0%, #BDF6C6 100%)',
    padding: 8,
  },
  
});
