import * as React from 'react';
import { Text, View, StyleSheet,Image,TextInput,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{background:'linear-gradient(180deg, rgba(189, 246, 198, 0) 0%, #BDF6C6 100%)'}}>
    <View style={{ flex:3,
    marginTop:"30px",
    
    flexDirection:"row",
    justifyContent:'center',
    }}>
    <Image
          style={{display:'flex',marginTop:"30px"
          }}
          source={require('./lock.png')}
        />
    </View>
    <View style={{flex:2,
    marginTop:'30px'}}>
      <Text style={{fontSize:"30px",
      fontWeight:"500",
      textAlign:"center",
      paddingTop:'10px',
      paddingLeft:"33px",
      paddingRight:"30px"      
      }}>FORGET PASSWORD</Text>
    </View>
    <View style={{flex:1,
    
    padding:'10px',
    marginTop:'30px',
    marginBottom:'5px'}}>
      <Text style={{fontWeight:'500',
      textAlign:'center',
      paddingLeft:'20px',
      paddingRight:'20px'}}>
      Provide your account’s email for which you want to reset your password</Text>
    </View>
    <View style={{flex:1,
  
    paddingLeft:'15px',
    paddingTop:'10px'}}>
      <TextInput
        style={{
          height: 40,
          width:300,
          backgroundColor:'gray',
          borderColor: 'gray',
          borderWidth: 1,
          paddingLeft:'10px',
          fontWeight:500
        }}
        placeholder='Email'
        
      />
    </View>
      <View style={{marginTop:'30px',paddingLeft:'15px',paddingBottom:'10px'}}>
        <TouchableOpacity
          style={{
            backgroundColor:"#E3C000",
            height:50,
            width:300,
            padding:13,
            marginRight:20,
            alignItems:'center',
            }}
          onPress={this.onPress}
        >
          <Text style={{
            fontSize: 15,
            fontWeight: "500",}}>NEXT</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

