import * as React from 'react';
        
import { Text, View, StyleSheet,TextInput,TouchableOpacity,Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.titlle}>LOGIN</Text>
      <View style={styles.body}>
        <TextInput
        style={styles.input}
        placeholder='Email'/>
        <TextInput
        style={styles.input}
        placeholder='Password'/>

        <TouchableOpacity
          style={styles.bt}
          onPress={this.onPress}>
          <Text style={{
            fontSize: 16,
            fontWeight: 500,}}>LOGIN</Text>
        </TouchableOpacity>
        <Text style={styles.tx1}>When you agree to terms and conditions</Text>
        <Text style={styles.tx2}>For got your password?</Text>
        <Text style={styles.tx3}>Or login with </Text>
      </View>
      <View style={styles.container2}>
        <View style={styles.item4}>
        <Image
          style={{display:'flex',marginLeft:'38px',marginTop:'5px'
          }}
          source={require('./Google__G__Logo.svg')}
        />
        </View>
        <View style={styles.item4}>
        <Image
          style={{display:'flex',marginLeft:'40px',marginTop:'5px'
          }}
          source={require('./Google__G__Logo.svg')}
        />
        </View>
        <View style={styles.item4}>
        <Image
          style={{display:'flex',marginLeft:'40px',marginTop:'5px'
          }}
          source={require('./Google__G__Logo.svg')}
        />
        </View>
      </View>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    background: 'rgba(49, 170, 82, 0.19)',
    padding: 8,
  },
  titlle:{
    textAlign:'center',
    fontSize:30,
    paddingTop:20,
    fontWeight:500
  },
  body:{
    marginTop:60,
    flex:1,
  },
  input:{
    height: 40,
    width:250,
    borderColor: 'gray',
    borderWidth: 1,
    paddingLeft:'10px',
    fontWeight:500,
    marginRight:20,
    marginLeft:34,
    marginTop:30
  },
  bt:{
    height:40,
    width:200,
    backgroundColor:'#E53935',
    margin:50,
    marginLeft:60,
    textAlign:'center',
    paddingTop:9,
  },
  tx1:{
    textAlign:'center',
    fontWeight:500,
    padding:30,
    paddingTop:5,
    paddingBottom:15,
    fontSize:10,
  },
  tx2:{
    textAlign:'center',
    fontWeight:500,
    color:'#5D25FA',
  },
  tx3:{
    textAlign:'center',
    fontWeight:500,
    paddingTop:10,
  },
  container2:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    marginTop:'10px'
  },
  item4:{
    border:'1px solid black',
    width:'100px',
    height:'40px',
    justifyContent:'center',
    backgroundColor:''
  }
});
